<?php

  $pth = realpath(dirname(__FILE__));
  $jsonname = "$pth/cache.json";
  $cdata = json_decode(file_get_contents($jsonname), true);
  $volts = $cdata["V"];
  $amps = $cdata["I"];
  $watts = $cdata["P"];
  $soc = $cdata["SOC"];
  $time = $cdata["TTG"];
  $raw = popen("sudo $pth/runcat.sh", "r");
  $rawlines = array();
  while ($rec = fgets($raw)) {
    $reca = str_replace("\t", " ", $rec);
    $rawlines[] = trim($reca);
  }
  $vup = false;
  $iup = false;
  $pup = false;
  $socup = false;
  $ttgup = false;
  foreach ($rawlines as $rawline) {
    if (substr($rawline, 0, 2) == "V ") {
      $volts = substr($rawline, 2) / 1000;
      $vup = true;
    }
    if (substr($rawline, 0, 2) == "I ") {
      $amps = substr($rawline, 2) / 1000;
      $iup = true;
    }
    if (substr($rawline, 0, 2) == "P ") {
      $watts = substr($rawline, 2) * 1;
      $pup = true;
    }
    if (substr($rawline, 0, 4) == "SOC ") {
      $soc = substr($rawline, 4) / 10;
      $socup = true;
    }
    if (substr($rawline, 0, 4) == "TTG ") {
      $time = substr($rawline, 4) * 1;
      $ttgup = true;
    }
  }
  if($vup == true && $iup == true && $pup == true && $socup == true && $ttgup == true) {
    $data = array();
    $data["V"] = $volts;
    $data["I"] = $amps;
    $data["P"] = $watts;
    $data["SOC"] = $soc;
    $data["TTG"] = $time;
    $json = json_encode($data);
    file_put_contents($jsonname, $json);
    echo $json;
  } else {
    echo false;
  }

?>
