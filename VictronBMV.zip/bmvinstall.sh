ttydev='/dev/ttyS0'

apt-get update
apt-get -y install apache2 libapache2-mod-php php
cd /var/www/html
wget https://raw.githubusercontent.com/sean6541/file/master/VictronBMV.zip
unzip ./VictronBMV.zip
rm ./VictronBMV.zip
chmod -R 755 ./VictronBMV
echo '<VirtualHost *:80>
	ServerAdmin webmaster@localhost
	DocumentRoot /var/www/html/VictronBMV
	ErrorLog ${APACHE_LOG_DIR}/error.log
	CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>' > /etc/apache2/sites-available/VictronBMV.conf
a2ensite VictronBMV
echo 'timeout 5 grep -a -m 1 PID -A 50 ' + $ttydev > ./VictronBMV/runcat.sh
chmod 755 ./VictronBMV/runcat.sh
echo 'ALL ALL=NOPASSWD: /var/www/html/VictronBMV/runcat.sh' | EDITOR='tee -a' visudo
echo '@reboot stty -F ' + $ttydev + ' speed 19200 raw -echo' | EDITOR='tee -a' crontab -e
echo 'Rebooting in 5 sec. Ctrl-C to cancel.'
sleep 5
reboot
