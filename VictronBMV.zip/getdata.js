window.onload = function() {
  update();
  setInterval(update, 5000);
};

function update() {
  $.get("getdata.php", function(rawdata){
    data = JSON.parse(rawdata);
    document.getElementById("volts").innerHTML = "Voltage: " + data["V"] + " V";
    document.getElementById("amps").innerHTML = "Current: " + data["I"] + " A";
    document.getElementById("watts").innerHTML = "Watts: " + data["P"] + " W";
    document.getElementById("soc").innerHTML = "Charge: " + data["SOC"] + " %";
    document.getElementById("time").innerHTML = "Time Remaining: " + data["TTG"] + " mins";
  });
}
