import os
import subprocess

path = os.path.dirname(os.path.abspath(__file__))
perm = 'chmod +x '
vncserver = '/bin/vncserver'
export = 'LD_LIBRARY_PATH='
libfile = '/resources/lib/'
conf = '/vncserver.conf'
argus = ' --config-file='
par = '"'
space = ' '
os.system(perm + path + vncserver)
subprocess.call(['sudo', '/sbin/modprobe', 'uinput'])
subprocess.call(['sudo', '/sbin/modprobe', 'evdev'])
os.system(export + par +  path + libfile + par + space + path + vncserver + argus + path + conf)
