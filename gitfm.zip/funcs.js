window.onload = function() {
  var sort_by = function(field, reverse, primer){
    var key = primer ?
    function(x) {return primer(x[field])} :
    function(x) {return x[field]};
    reverse = !reverse ? 1 : -1;
    return function (a, b) {
      return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
    }
  }
  function findGetParameter(parameterName) {
      var result = null,
          tmp = [];
      location.search
          .substr(1)
          .split("&")
          .forEach(function (item) {
            tmp = item.split("=");
            if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
          });
      return result;
  }
  user = "<username>";
  toke = "<personalaccesstoken>";
  repos = "<reponame>";
  urlprefix = "https://raw.githubusercontent.com/" + user + "/" + repos + "/master/";
  pth = findGetParameter("path");
  if(pth == null) {
    pth = "";
  } else if(pth[0] == "/") {
    pth = pth.substr(1, pth.length);
  }
  if(pth.indexOf("/") == -1) {
    prevpth = "";
  } else {
    prevpth = pth.substr(0, pth.lastIndexOf("/"));
  }
  url = $.param.querystring(window.location.href, "path=" + prevpth);
  document.getElementById("files").innerHTML = `<div class="card" style="margin-top: 15px;">
<div class="card-body">
<div><a href="` + url + `">Back (..)</a></div>
</div>
</div>`;
gh = new GitHub({
  username: user,
  password: toke
});
repo = gh.getRepo(user, repos);
repo.getContents("master", pth, false, loaded);
function loaded(error, result, request) {
  result.sort(sort_by('name', false, function(a){return a.toUpperCase()}));
    for (const item of result) {
      if (item.type == "file") {
        url = urlprefix + item.path;
        path = item.path;
        name = item.name;
        document.getElementById("files").innerHTML += `<div class="card" style="margin-top: 15px;">
<div class="card-body">
<div style="float: left;"><a href="` + url + `">` + name + `</a></div>
<div style="float: right;"><a class="text-muted">File</a></div>
<div style="clear: both;"></div>
</div>
</div>`;
      } else if (item.type == "dir") {
        url = $.param.querystring(window.location.href, "path=" + item.path);
        path = item.path;
        name = item.name;
        document.getElementById("files").innerHTML += `<div class="card" style="margin-top: 15px;">
<div class="card-body">
<div style="float: left;"><a href="` + url + `">` + name + `</a></div>
<div style="float: right;"><a class="text-muted">Directory</a></div>
<div style="clear: both;"></div>
</div>
</div>`;
      }
    }
  }
};
